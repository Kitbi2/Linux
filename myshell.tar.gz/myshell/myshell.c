#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
#include"tmp.h"

int main(int argc,char * argv[])
{
    char usercmd[1024] = {'\0'};
    char * ret = NULL;
    char cmd[1024] = {'\0'};
    char arg[1024] = {'\0'};
    char * argc_r[1024] = {NULL};
    int arg_num = 0;
    char * head = NULL;
    char * end = NULL;

    pid_t id = 0;
    while(1)
    {
        memset(cmd,'\0',1024);
        memset(arg,'\0',1024);
        memset(argc_r,0,1024);
        printf("%s@ubuntu:%s$ ",getUsername(),getpwd());

        /* 读取命令和参数 */
        ret = fgets(usercmd,1024,stdin);
        if(ret == NULL)
            return 1;

        usercmd[strlen(usercmd) - 1] = '\0';

        
        Getcmd(usercmd,&head,&end);
        Wcmd(cmd,head,end);
        argc_r[0] = cmd;
        Warg(arg,end+1,argc_r + 1);

        myexelc(cmd,argc_r);
        // wait(NULL);
    }
    // printf("%s",usercmd);
    return 0;
}
