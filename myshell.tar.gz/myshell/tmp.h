#ifndef TMP_H
#define TMP_H


const char * getUsername(void);
const char * getHostname(void);
const char * getpwd(void);
void Getcmd(char * targt,char ** head,char ** end);
void Wcmd(char * targt,char * head,char * end);
// void Warg(char * targt,char * head,int * arg_Num);
void Warg(char * targt,char * head,char ** argc_r);
void myexelc(char * cmd,char ** argc_r);
#endif

