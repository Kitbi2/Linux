#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>
const char * getUsername(void)
{
    const char * name = getenv("USER");
    if(name == NULL)
        return "noget";
    return name;
}

const char * getHostname(void)
{
    const char * name = getenv("HOSTNAME");
    
    if(name == NULL)
        return "noget";
    return name;
}

const char * getpwd(void)
{
    const char * name = getenv("PWD");
    if(name == NULL)
        return "noget";
    return name;
}


void Getcmd(char * targt,char ** head,char ** end)
{
    *head = targt;
    *end = targt;
    if(targt == NULL)
    {
        return;
    }
    while(**end != '\0' && ** end != ' ')
    {
        (*end)++;
    }
    
}

void Wcmd(char * targt,char * head,char * end)
{
    if(head == NULL || end == NULL)
    {
        return;
    }

    while(head != end)
    {
        *targt = *head;
        targt++;
        head++;
    }
    *targt = '\0';


}

// void Warg(char * targt,char * head,int * arg_Num)
// {
//     if(NULL == head || *head == '\0')
//     {
//         *arg_Num = 0;
//         return;
//     }
//     while(*head != '\0')
//     {
//         if(*head != ' ')
//         {
//             *targt = *head;
//         }
//         else
//         {   
//             *targt = '\0';
//             (*arg_Num)++;
//         }
//         targt++;
//         head++;
//     }
//     (*arg_Num)++; 
// }
void Warg(char * targt,char * head,char ** argc_r)
{
    int arc_Num = 0;
    char * cur = targt;
    if(NULL == head || *head == '\0')
    {
        arc_Num = 0;
        return;
    }
    while(*head != '\0')
    {
        if(*head != ' ')
        {
            *cur = *head;
        }
        else
        {   
            *cur = '\0';
            arc_Num++;
        }
        cur++;
        head++;
    }
    arc_Num++;

    head = targt;
    char * end = targt;
    int i = 0;
    while(arc_Num)
    {
        if(*end == '\0')
        {
            argc_r[i] = head;
            i++;
            head = end + 1;
            arc_Num--;
        }
        end++;
        
    }

}

void myexelc(char * cmd,char ** argc_r)
{
    pid_t id = 0;
    if(!strcmp(argc_r[0],"cd"))
    {
        chdir(argc_r[1]);
        setenv("PWD",argc_r[1],1);
    }    
    else
    {
        id = fork();
     
        wait(NULL);
        if(0 == id)
        {
            execvp(cmd,argc_r);
        }
    }
}