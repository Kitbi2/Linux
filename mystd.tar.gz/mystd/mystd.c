#include<string.h>
#include<stdlib.h>
#include<sys/types.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<unistd.h>
#include<errno.h>
#include<stdio.h>
#include"mystd.h"


My_FILE * My_fopen(const char * file,const char * mode)
{
    int flag = 0;
    int fd = 0;
    My_FILE * ret = NULL;
    if(strcmp(mode,"r") == 0)
    {
        flag |= O_RDONLY;
    }
    else  if(strcmp(mode,"w") == 0)
    {
        flag = O_CREAT | O_WRONLY | O_TRUNC;
    }
    else if(strcmp(mode,"a") == 0)
    {
        flag = O_CREAT | O_WRONLY | O_APPEND ;
    }


    if(flag & O_CREAT)
    {
       fd =  open(file,flag,0664);
    }
    else 
    {
        fd = open(file,flag);
    }
    if(fd == -1)
    {
        errno = 2;
        perror("file fopen error\n");
        return ret;
    }

    ret = (My_FILE*)malloc(sizeof(My_FILE));
    if(ret == NULL)
    {
        errno = 2;
        perror("malloc error\n");
        return ret;       
    }

    ret->fileno = fd;
    ret->end = 0;
    
}


int My_fwrite(My_FILE * stream,const void * buf,int size)
{
    memcpy(stream->buf + stream->end,buf,size);

    stream->end += size;
    if(stream->buf[stream->end - 1] == '\n')
    {
        My_fflush(stream);
    }

}

void My_fflush(My_FILE * stream)
{
    if(stream->end != 0)
    {
        write(stream->fileno,stream->buf,stream->end);
        stream->end = 0;
    }

}

void MY_fclose(My_FILE * stream)
{
    if(stream->end != 0)
    {
        My_fflush(stream);
    }
    close(stream->fileno);

}