#include"mystd.h"
#include<string.h>


int main(int argc,char * argv[])
{
    const char * buf = "hello yjt\n";
    My_FILE * file = My_fopen("log.txt","w");

    My_fwrite(file,buf,strlen(buf));

    MY_fclose(file);
}