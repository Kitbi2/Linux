#ifndef MYSTD_H
#define MYSTD_H
typedef struct My_FILE
{
    int fileno;//文件描述符号
    char buf[1024];
    int end;
}My_FILE;


My_FILE * My_fopen(const char * file,const char * mode);

int My_fwrite(My_FILE * stream,const void * buf,int size);

void My_fflush(My_FILE * stream);

void MY_fclose(My_FILE * stream);
#endif


